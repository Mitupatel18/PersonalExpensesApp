# Personal Expense Tracker — CSV version (Tkinter GUI)
# Features:
# - Login & Register (CSV)
# - Add / View / Delete expenses (CSV)
# - Filter by date range
# - Monthly & Yearly reports
# - Export to PDF (reportlab)
# - Modern sidebar layout + Dark / Light mode

import csv, os
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from reportlab.pdfgen import canvas
from io import BytesIO


pdfmetrics.registerFont(TTFont('DejaVu', 'ttf/DejaVuSans.ttf'))

# ---------------- files ----------------
USER_FILE = "users.csv"
EXPENSE_FILE = "expenses.csv"

# ensure files exist
if not os.path.exists(USER_FILE):
    with open(USER_FILE, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["username", "password"])  # header

if not os.path.exists(EXPENSE_FILE):
    with open(EXPENSE_FILE, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["username", "date", "category", "amount", "description"])  # header

# ---------------- helpers ----------------
def read_users():
    with open(USER_FILE, "r", newline="") as f:
        reader = csv.reader(f)
        next(reader, None)
        return [row for row in reader]

def append_user(username, password):
    with open(USER_FILE, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([username, password])

def read_expenses():
    with open(EXPENSE_FILE, "r", newline="") as f:
        reader = csv.reader(f)
        next(reader, None)
        return [row for row in reader]

def write_expenses(rows):
    with open(EXPENSE_FILE, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["username", "date", "category", "amount", "description"])  # header
        writer.writerows(rows)

# ---------------- PDF export ----------------
def export_pdf_for_user(username, start_date=None, end_date=None, filename=None):
    if not filename:
        filename = filedialog.asksaveasfilename(defaultextension='.pdf', filetypes=[('PDF files', '*.pdf')])
        if not filename:
            return

    styles = getSampleStyleSheet()
    styles['Normal'].fontName = 'DejaVu'
    styles['Heading1'].fontName = 'DejaVu'
    story = []
    story.append(Paragraph(f"Expense Report — {username}", styles['Title']))
    story.append(Spacer(1, 8))
    story.append(Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal']))
    story.append(Spacer(1, 12))

    # summary by category
    rows = read_expenses()
    filtered = []
    for u, d, c, a, desc in rows:
        if u == username:
            if start_date and end_date:
                try:
                    dt = datetime.strptime(d, "%Y-%m-%d")
                    if not (start_date <= dt <= end_date):
                        continue
                except Exception:
                    continue
            filtered.append((u, d, c, a, desc))

    # summary
    summary = {}
    for _, d, c, a, desc in filtered:
        try:
            val = float(a)
        except Exception:
            val = 0.0
        summary[c] = summary.get(c, 0.0) + val

    if summary:
        story.append(Paragraph('Summary by category', styles['Heading2']))
        data = [['Category', 'Total (₹)']]
        total = 0.0
        for cat, amt in summary.items():
            data.append([cat, f"{amt:.2f}"])
            total += amt;
        tbl = Table(data, hAlign='LEFT')
        tbl.setStyle(TableStyle([('FONTNAME', (0,0), (-1,-1), 'DejaVu'), ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#dfe7fd')), ('GRID', (0,0), (-1,-1), 0.25, colors.gray)]))
        story.append(tbl)
        story.append(Spacer(1, 12))
        story.append(Paragraph(f'Total Expenses: ₹{total:.2f}', styles['Normal']))
        story.append(Spacer(1, 12))



        # Add pie chart
        try:
            fig = plt.Figure(figsize=(5, 3.5), dpi=100)
            ax = fig.add_subplot(111)
            ax.pie(summary.values(), labels=summary.keys(), autopct="%1.1f%%", startangle=90)
            
            # Set title based on date range
            if start_date and end_date:
                title = f"Category-wise Spending ({start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')})"
            else:
                title = "Category-wise Spending (All Time)"
            ax.set_title(title, fontsize=10, fontweight='bold')
            
            # Save chart to BytesIO
            img_buffer = BytesIO()
            fig.savefig(img_buffer, format='png', bbox_inches='tight', dpi=100)
            img_buffer.seek(0)
            plt.close(fig)
            
            # Add chart to PDF
            story.append(Paragraph('Expense Chart', styles['Heading2']))
            story.append(Spacer(1, 8))
            chart_img = Image(img_buffer, width=250, height=250)
            story.append(chart_img)
            story.append(Spacer(1, 12))
        except Exception as e:
            print(f"Chart generation error: {e}")




    # details
    if filtered:
        story.append(Paragraph('Expenses', styles['Heading2']))
        data = [['Date', 'Category', 'Amount (₹)', 'Description']]
        for _, d, c, a, desc in filtered:
            data.append([d, c, a, desc or ''])
        tbl = Table(data, hAlign='LEFT', colWidths=[80, 100, 80, 220])
        tbl.setStyle(TableStyle([('FONTNAME', (0,0), (-1,-1), 'DejaVu'), ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#f0f0f0')), ('GRID', (0,0), (-1,-1), 0.25, colors.gray)]))
        story.append(tbl)

    doc = SimpleDocTemplate(filename, pagesize=letter)
    doc.build(story)
    messagebox.showinfo('Exported', f'PDF exported to: {filename}')

# ---------------- GUI app ----------------
class ExpenseApp:
    def __init__(self, root, username):
        self.root = root
        self.username = username
        self.root.title(f"Expense Tracker — {username}")
        self.root.geometry('900x600')
        self.is_dark = False

        # layout
        self.sidebar = tk.Frame(root, width=200, bg='#efefef')
        self.sidebar.pack(side='left', fill='y')
        self.content = tk.Frame(root, bg='white')
        self.content.pack(side='right', fill='both', expand=True)

        self.build_sidebar()
        self.build_content()
        self.load_expenses_into_tree()

    def build_sidebar(self):
        tk.Label(self.sidebar, text='MENU', bg='#cccccc', font=('Arial', 14)).pack(fill='x')

        btns = [
            ('Add Expense', self.open_add_window),
            ('View All', self.load_expenses_into_tree),
            ('Summary', self.show_summary),
            ('Filter by Date', self.open_filter_window),
            ('Monthly Report', self.show_monthly_report),
            ('Yearly Report', self.show_yearly_report),
            ('Export to PDF', self.open_export_prompt),
            ("Charts", self.chart_screen),
            ('Toggle Dark Mode', self.toggle_dark_mode),
            ('Logout', self.logout)
        ]

        for t, cmd in btns:
            b = tk.Button(self.sidebar, text=t, anchor='w', command=cmd)
            b.pack(fill='x', padx=5, pady=4)

    def build_content(self):
        # top controls
        top = tk.Frame(self.content, bg='white')
        top.pack(fill='x')

        tk.Label(top, text=f'Logged in as: {self.username}', bg='white').pack(side='left', padx=8, pady=8)

        # tree
        cols = ('date', 'category', 'amount', 'description')
        self.tree = ttk.Treeview(self.content, columns=cols, show='headings')
        for c in cols:
            self.tree.heading(c, text=c.title())
            self.tree.column(c, width=150)
        self.tree.pack(fill='both', expand=True, padx=8, pady=8)

        # bottom buttons
        bottom = tk.Frame(self.content, bg='white')
        bottom.pack(fill='x')
        tk.Button(bottom, text='Delete Selected', bg='#e53935', fg='white', command=self.delete_selected).pack(side='left', padx=8, pady=6)
        tk.Button(bottom, text='Refresh', command=self.load_expenses_into_tree).pack(side='left', padx=8)

    def load_expenses_into_tree(self):
        for r in self.tree.get_children():
            self.tree.delete(r)
        rows = read_expenses()
        for user, date, cat, amt, desc in rows:
            if user == self.username:
                self.tree.insert('', 'end', values=(date, cat, amt, desc))

    def open_add_window(self):
        win = tk.Toplevel(self.root)
        win.title('Add Expense')
        win.geometry('320x260')

        tk.Label(win, text='Category').pack(pady=6)
        cat_ent = tk.Entry(win)
        cat_ent.pack()

        tk.Label(win, text='Amount').pack(pady=6)
        amt_ent = tk.Entry(win)
        amt_ent.pack()

        tk.Label(win, text='Date (YYYY-MM-DD)').pack(pady=6)
        date_ent = tk.Entry(win)
        date_ent.insert(0, datetime.now().strftime('%Y-%m-%d'))
        date_ent.pack()

        tk.Label(win, text='Description').pack(pady=6)
        desc_ent = tk.Entry(win)
        desc_ent.pack()

        def save():
            cat = cat_ent.get().strip()
            amt = amt_ent.get().strip()
            date = date_ent.get().strip()
            desc = desc_ent.get().strip()
            if not cat or not amt or not date:
                messagebox.showwarning('Required', 'Category, amount and date are required')
                return
            try:
                float(amt)
                datetime.strptime(date, '%Y-%m-%d')
            except Exception:
                messagebox.showwarning('Format', 'Amount must be number and date YYYY-MM-DD')
                return
            with open(EXPENSE_FILE, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([self.username, date, cat, amt, desc])
            win.destroy()
            self.load_expenses_into_tree()

        tk.Button(win, text='Save', command=save).pack(pady=10)

    def delete_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning('Select', 'Please select a row')
            return
        if not messagebox.askyesno('Confirm', 'Delete selected expense?'):
            return
        vals = self.tree.item(sel[0])['values']
        date, cat, amt, desc = vals
        rows = read_expenses()
        new_rows = [r for r in rows if not (r[0] == self.username and r[1] == date and r[2] == cat and r[3] == amt and r[4] == desc)]
        write_expenses(new_rows)
        self.load_expenses_into_tree()
        messagebox.showinfo('Deleted', 'Expense deleted')

    def show_summary(self):
        total = {}
        for u, d, c, a, desc in read_expenses():
            if u == self.username:
                try:
                    val = float(a)
                except Exception:
                    val = 0.0
                total[c] = total.get(c, 0.0) + val
        if not total:
            messagebox.showinfo('Summary', 'No data found')
            return
        text = ''.join([f"{c}: ₹{v:.2f}" for c, v in total.items()])
        messagebox.showinfo('Summary', text)

    def open_filter_window(self):
        win = tk.Toplevel(self.root)
        win.title('Filter by Date')
        win.geometry('320x180')

        tk.Label(win, text='Start (YYYY-MM-DD)').pack(pady=4)
        start_ent = tk.Entry(win)
        start_ent.pack()

        tk.Label(win, text='End (YYYY-MM-DD)').pack(pady=4)
        end_ent = tk.Entry(win)
        end_ent.pack()

        def apply_filter():
            s = start_ent.get().strip()
            e = end_ent.get().strip()
            try:
                sdt = datetime.strptime(s, '%Y-%m-%d')
                edt = datetime.strptime(e, '%Y-%m-%d')
            except Exception:
                messagebox.showwarning('Format', 'Use YYYY-MM-DD')
                return
            for r in self.tree.get_children():
                self.tree.delete(r)
            for u, d, c, a, desc in read_expenses():
                if u == self.username:
                    try:
                        dt = datetime.strptime(d, '%Y-%m-%d')
                        if sdt <= dt <= edt:
                            self.tree.insert('', 'end', values=(d, c, a, desc))
                    except Exception:
                        continue
            win.destroy()

        tk.Button(win, text='Apply', command=apply_filter).pack(pady=10)

    def show_monthly_report(self):
        year_month = simpledialog.askstring('Month', 'Enter month (YYYY-MM) — leave empty for current month')
        if not year_month:
            year_month = datetime.now().strftime('%Y-%m')
        total = 0.0
        for u, d, c, a, desc in read_expenses():
            if u == self.username and d.startswith(year_month):
                try:
                    total += float(a)
                except Exception:
                    continue
        messagebox.showinfo('Monthly Report', f'Total for {year_month}: ₹{total:.2f}')

    def show_yearly_report(self):
        year = simpledialog.askstring('Year', 'Enter year (YYYY) — leave empty for current year')
        if not year:
            year = datetime.now().strftime('%Y')
        total = 0.0
        for u, d, c, a, desc in read_expenses():
            if u == self.username and d.startswith(year):
                try:
                    total += float(a)
                except Exception:
                    continue
        messagebox.showinfo('Yearly Report', f'Total for {year}: ₹{total:.2f}')
        
        

    def open_export_prompt(self):
        if messagebox.askyesno('Range', 'Export date range?'):
            s = simpledialog.askstring('Start', 'Start date (YYYY-MM-DD)')
            e = simpledialog.askstring('End', 'End date (YYYY-MM-DD)')
            try:
                sdt = datetime.strptime(s, '%Y-%m-%d')
                edt = datetime.strptime(e, '%Y-%m-%d')
            except Exception:
                messagebox.showwarning('Format', 'Use YYYY-MM-DD')
                return
            export_pdf_for_user(self.username, sdt, edt)
        else:
            export_pdf_for_user(self.username)
        
        
        
    def chart_screen(self):
        win = tk.Toplevel(self.root)
        win.title('Expense Chart')
        
        
        # win.geometry('600x500')
        try:
            import ctypes
            monitors = ctypes.windll.user32.GetSystemMetrics
            sw = monitors(78)
            sh = monitors(79)
            pw = monitors(0)
            ph = monitors(1)
            if sw > pw:
                win.geometry(f"600x500+{pw}+0")
        except:
            pass
        
        
        # Ask user for date range
        use_range = messagebox.askyesno('Date Range', 'Filter chart by date range?')
        start_date = None
        end_date = None
        
        if use_range:
            s = simpledialog.askstring('Start Date', 'Enter start date (YYYY-MM-DD)')
            e = simpledialog.askstring('End Date', 'Enter end date (YYYY-MM-DD)')
            
            try:
                start_date = datetime.strptime(s, '%Y-%m-%d')
                end_date = datetime.strptime(e, '%Y-%m-%d')
            except Exception:
                messagebox.showwarning('Format', 'Invalid date format. Use YYYY-MM-DD')
                win.destroy()
                return
        
        
        rows = [r for r in read_expenses() if r[0] == self.username]
        
        # Filter by date range if provided
        if start_date and end_date:
            filtered_rows = []
            for r in rows:
                try:
                    dt = datetime.strptime(r[1], '%Y-%m-%d')
                    if start_date <= dt <= end_date:
                        filtered_rows.append(r)
                except Exception:
                    continue
            rows = filtered_rows
            
            
        cats = {}
        for r in rows:
            c = r[2]
            try:
                amt = float(r[3])
                cats[c] = cats.get(c, 0) + amt
            except ValueError:
                continue
            
        if not cats:
            messagebox.showinfo('Chart', 'No expense data available')
            win.destroy()
            return


        fig = plt.Figure(figsize=(6,4), dpi=100)
        ax = fig.add_subplot(111)
        ax.pie(cats.values(), labels=cats.keys(), autopct="%1.1f%%", startangle=90)
        
        # Add date range to title if filtered
        if start_date and end_date:
            title = f"Category-wise Spending ({start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')})"
        else:
            title = "Category-wise Spending (All Time)"
        ax.set_title(title)

        chart = FigureCanvasTkAgg(fig, win)
        chart.get_tk_widget().pack(fill="both", expand=True)
        
        

    def toggle_dark_mode(self):
        self.is_dark = not self.is_dark
        if self.is_dark:
            bg = '#222222'; fg = '#f0f0f0'
            sidebar_bg = '#2b2b2b'
        else:
            bg = '#ffffff'; fg = '#000000'
            sidebar_bg = '#efefef'
        self.root.configure(bg=bg)
        self.sidebar.configure(bg=sidebar_bg)
        self.content.configure(bg=bg)

    def logout(self):
        if messagebox.askyesno('Logout', 'Are you sure?'):
            self.root.destroy()
            main()

# ---------------- login window ----------------
class LoginWindow:
    def __init__(self, root):
        self.root = root
        root.title('Login — Expense Tracker')
        root.geometry('360x260')

        frm = tk.Frame(root)
        frm.pack(pady=20)

        tk.Label(frm, text='Username').grid(row=0, column=0, sticky='e', padx=6, pady=6)
        self.user_ent = tk.Entry(frm)
        self.user_ent.grid(row=0, column=1)

        tk.Label(frm, text='Password').grid(row=1, column=0, sticky='e', padx=6, pady=6)
        self.pwd_ent = tk.Entry(frm, show='*')
        self.pwd_ent.grid(row=1, column=1)

        tk.Button(frm, text='Login', command=self.login).grid(row=2, column=0, columnspan=2, pady=10)
        tk.Button(frm, text='Register', command=self.register).grid(row=3, column=0, columnspan=2)

    def login(self):
        u = self.user_ent.get().strip()
        p = self.pwd_ent.get().strip()
        if not u or not p:
            messagebox.showwarning('Input', 'Enter both username and password')
            return
        users = read_users()
        for user, pwd in users:
            if user == u and pwd == p:
                self.root.destroy()
                app_root = tk.Tk()
                ExpenseApp(app_root, u)
                app_root.mainloop()
                return
        messagebox.showerror('Login failed', 'Invalid credentials')

    def register(self):
        u = self.user_ent.get().strip()
        p = self.pwd_ent.get().strip()
        if not u or not p:
            messagebox.showwarning('Input', 'Enter both username and password')
            return
        users = read_users()
        for user, pwd in users:
            if user == u:
                messagebox.showwarning('Exists', 'Username already exists')
                return
        append_user(u, p)
        messagebox.showinfo('Registered', 'Account created — you can login now')

# ---------------- main ----------------
def main():
    root = tk.Tk()
    LoginWindow(root)
    root.mainloop()

if __name__ == '__main__':
    main()
