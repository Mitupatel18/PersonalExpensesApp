# Django CSV-backed Expense Tracker

This project was auto-generated from your Tkinter CSV expense tracker.
It uses CSV files for users and expenses (keeps the original CSV logic).

## Files created
Location: /mnt/data/expense_csv_site

- manage.py
- expense_site/ (Django settings)
- tracker/ (Django app with views, templates, utils)
- data/ (contains users.csv, expenses.csv, and a copy of your original Tkinter app)

## Quick start (local)
1. Create and activate a virtualenv:
   ```bash
   python -m venv venv
   source venv/bin/activate   # or venv\Scripts\activate on Windows
   pip install django reportlab matplotlib
   ```

2. Run migrations (Django uses sessions/messages):
   ```bash
   python manage.py migrate
   ```

3. Start the dev server:
   ```bash
   python manage.py runserver
   ```

4. Open http://127.0.0.1:8000/ in your browser.

Notes:
- Users are stored in `data/users.csv` (plain text passwords like your original app).
- Expenses are in `data/expenses.csv`.
- To switch to Django auth and database-backed expenses, ask me and I will convert.
