import csv
from django.conf import settings

USER_FILE = settings.USER_FILE
EXPENSE_FILE = settings.EXPENSE_FILE

def read_users():
    with open(USER_FILE, 'r', newline='') as f:
        reader = csv.reader(f)
        next(reader, None)
        return [row for row in reader]

def append_user(username, password):
    with open(USER_FILE, 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([username, password])

def read_expenses():
    with open(EXPENSE_FILE, 'r', newline='') as f:
        reader = csv.reader(f)
        next(reader, None)
        return [row for row in reader]

def write_expenses(rows):
    with open(EXPENSE_FILE, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['username', 'date', 'category', 'amount', 'description'])
        writer.writerows(rows)

def append_expense(username, date, category, amount, description):
    with open(EXPENSE_FILE, 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([username, date, category, amount, description])

def expenses_for_user(username):
    return [r for r in read_expenses() if r[0] == username]
