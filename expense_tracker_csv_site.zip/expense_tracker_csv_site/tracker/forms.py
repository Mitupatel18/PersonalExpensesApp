from django import forms

class LoginForm(forms.Form):
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)

class RegisterForm(forms.Form):
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)

class ExpenseForm(forms.Form):
    category = forms.CharField(max_length=100)
    amount = forms.DecimalField(max_digits=12, decimal_places=2)
    date = forms.DateField(input_formats=['%Y-%m-%d'])
    description = forms.CharField(required=False)