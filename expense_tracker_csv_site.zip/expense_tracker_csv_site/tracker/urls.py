from django.urls import path
from . import views

app_name = 'tracker'

urlpatterns = [
    path('', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('add/', views.add_expense, name='add_expense'),
    path('delete/', views.delete_expense, name='delete_expense'),
    path('export_pdf/', views.export_pdf, name='export_pdf'),
    path('chart_png/', views.chart_png, name='chart_png'),
    path('logout/', views.logout_view, name='logout'),
]
