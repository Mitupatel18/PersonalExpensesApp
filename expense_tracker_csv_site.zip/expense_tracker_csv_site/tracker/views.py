from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseForbidden
from django.contrib import messages
from .forms import LoginForm, RegisterForm, ExpenseForm
from . import utils
from datetime import datetime
from django.conf import settings
from io import BytesIO
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import matplotlib.pyplot as plt

try:
    pdfmetrics.registerFont(TTFont('DejaVu', '../ttf/DejaVuSans.ttf'))
except Exception:
    pass

def login_view(request):
    if 'username' in request.session:
        return redirect('tracker:dashboard')
    
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            u = form.cleaned_data['username']
            p = form.cleaned_data['password']
            users = utils.read_users()
            for user, pwd in users:
                if user == u and pwd == p:
                    request.session['username'] = u
                    return redirect('tracker:dashboard')
            messages.error(request, 'Invalid credentials')
    else:
        form = LoginForm()
    return render(request, 'tracker/login.html', {'form': form})

def register_view(request):
    if 'username' in request.session:
        return redirect('tracker:dashboard')
    
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            u = form.cleaned_data['username']
            p = form.cleaned_data['password']
            for user, pwd in utils.read_users():
                if user == u:
                    messages.warning(request, 'Username already exists')
                    return redirect('tracker:register')
            utils.append_user(u, p)
            messages.success(request, 'Registered — you can login now')
            return redirect('tracker:login')
    else:
        form = RegisterForm()
    return render(request, 'tracker/register.html', {'form': form})

def logout_view(request):
    request.session.pop('username', None)
    return redirect('tracker:login')

def require_login(fn):
    def inner(request, *args, **kwargs):
        if 'username' not in request.session:
            return redirect('tracker:login')
        return fn(request, *args, **kwargs)
    return inner

@require_login
def dashboard(request):
    user = request.session['username']
    rows = utils.expenses_for_user(user)
    
    start_date = request.GET.get('start', '')
    end_date = request.GET.get('end', '')
    
    expenses = []
    for r in rows:
        try:
            if start_date and end_date:
                dt = datetime.strptime(r[1], '%Y-%m-%d')
                start = datetime.strptime(start_date, '%Y-%m-%d')
                end = datetime.strptime(end_date, '%Y-%m-%d')
                if not (start <= dt <= end):
                    continue
        except Exception:
            pass
        expenses.append({'date': r[1], 'category': r[2], 'amount': r[3], 'description': r[4]})
        
    
    return render(request, 'tracker/dashboard.html', {'username': user, 'expenses': expenses, 'start_date': start_date, 'end_date': end_date})

@require_login
def add_expense(request):
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        if form.is_valid():
            user = request.session['username']
            utils.append_expense(user, form.cleaned_data['date'].strftime('%Y-%m-%d'), form.cleaned_data['category'], str(form.cleaned_data['amount']), form.cleaned_data['description'])
            messages.success(request, 'Expense added')
            return redirect('tracker:dashboard')
    else:
        form = ExpenseForm(initial={'date': datetime.now().strftime('%Y-%m-%d')})
    return render(request, 'tracker/add_expense.html', {'form': form})

@require_login
def delete_expense(request):
    if request.method != 'POST':
        return HttpResponseForbidden()
    user = request.session['username']
    date = request.POST.get('date')
    category = request.POST.get('category')
    amount = request.POST.get('amount')
    description = request.POST.get('description', '')
    rows = utils.read_expenses()
    new_rows = [r for r in rows if not (r[0] == user and r[1] == date and r[2] == category and r[3] == amount and r[4] == description)]
    utils.write_expenses(new_rows)
    messages.success(request, 'Deleted')
    return redirect('tracker:dashboard')

@require_login
def export_pdf(request):
    user = request.session['username']
    s = request.GET.get('start')
    e = request.GET.get('end')
    start_date = None
    end_date = None
    try:
        if s:
            start_date = datetime.strptime(s, '%Y-%m-%d')
        if e:
            end_date = datetime.strptime(e, '%Y-%m-%d')
    except Exception:
        messages.error(request, 'Invalid date format')
        return redirect('tracker:dashboard')

    rows = utils.expenses_for_user(user)
    filtered = []
    for u, d, c, a, desc in rows:
        try:
            dt = datetime.strptime(d, '%Y-%m-%d')
            if start_date and end_date:
                if not (start_date <= dt <= end_date):
                    continue
        except Exception:
            pass
        filtered.append((u, d, c, a, desc))

    buf = BytesIO()
    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(buf)
    story = []
    story.append(Paragraph(f'Expense Report — {user}', styles['Title']))
    story.append(Spacer(1, 8))
    story.append(Paragraph(f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}', styles['Normal']))
    story.append(Spacer(1, 12))

    summary = {}
    for _, d, c, a, desc in filtered:
        try:
            val = float(a)
        except Exception:
            val = 0.0
        summary[c] = summary.get(c, 0.0) + val

    if summary:
        story.append(Paragraph('Summary by category', styles['Heading2']))
        data = [['Category', 'Total (Rs.)']]
        total = 0.0
        for cat, amt in summary.items():
            data.append([cat, f'{amt:.2f}'])
            total += amt
        tbl = Table(data, hAlign='LEFT')
        tbl.setStyle(TableStyle([('BACKGROUND', (0,0), (-1,0), colors.HexColor('#dfe7fd')), ('GRID', (0,0), (-1,-1), 0.25, colors.gray)]))
        story.append(tbl)
        story.append(Spacer(1, 12))
        story.append(Paragraph(f'Total Expenses: Rs.{total:.2f}', styles['Normal']))
        story.append(Spacer(1, 12))

        try:
            fig = plt.Figure(figsize=(4,3), dpi=100)
            ax = fig.add_subplot(111)
            ax.pie(summary.values(), labels=summary.keys(), autopct='%1.1f%%', startangle=90)
            imgbuf = BytesIO()
            fig.savefig(imgbuf, format='png', bbox_inches='tight')
            imgbuf.seek(0)
            story.append(Image(imgbuf, width=250, height=200))
        except Exception:
            pass

    if filtered:
        story.append(Paragraph('Details', styles['Heading2']))
        data = [['Date', 'Category', 'Amount (Rs.)', 'Description']]
        for _, d, c, a, desc in filtered:
            data.append([d, c, a, desc or ''])
        tbl = Table(data, colWidths=[80, 100, 80, 200])
        tbl.setStyle(TableStyle([('GRID', (0,0), (-1,-1), 0.25, colors.gray)]))
        story.append(tbl)

    doc.build(story)
    buf.seek(0)
    return HttpResponse(buf.getvalue(), content_type='application/pdf')

@require_login
def chart_png(request):
    user = request.session['username']
    s = request.GET.get('start')
    e = request.GET.get('end')
    start_date = None
    end_date = None
    try:
        if s:
            start_date = datetime.strptime(s, '%Y-%m-%d')
        if e:
            end_date = datetime.strptime(e, '%Y-%m-%d')
    except Exception:
        pass

    rows = utils.expenses_for_user(user)
    filtered = []
    for r in rows:
        try:
            dt = datetime.strptime(r[1], '%Y-%m-%d')
            if start_date and end_date and not (start_date <= dt <= end_date):
                continue
        except Exception:
            pass
        filtered.append(r)

    cats = {}
    for r in filtered:
        try:
            amt = float(r[3])
            cats[r[2]] = cats.get(r[2], 0.0) + amt
        except Exception:
            continue
    if not cats:
        return HttpResponse(status=204)

    fig = plt.Figure(figsize=(6,4))
    ax = fig.add_subplot(111)
    ax.pie(cats.values(), labels=cats.keys(), autopct='%1.1f%%', startangle=90)
    ax.set_title('Category-wise Spending')
    buf = BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight')
    buf.seek(0)
    return HttpResponse(buf.getvalue(), content_type='image/png')
